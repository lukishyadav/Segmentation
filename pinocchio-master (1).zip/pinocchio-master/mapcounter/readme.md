To run the latest version of the code, run:
```
bokeh serve frontend.py
```
at your command prompt. Then navigate to the URL http://localhost:5006/frontend in your browser.
