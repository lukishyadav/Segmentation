region = {
    'oakland': dict(
        x_min=-13618976.4221,
        x_max=-13605638.1607,
        y_min=4549035.0828,
        y_max=4564284.2700,
        timezone='America/Los_Angeles'),
    'madrid': dict(
        x_min=-416448.0394,
        x_max=-406912.5201,
        y_min=4921025.4356,
        y_max=4931545.0816,
        timezone='Europe/Madrid')
}
