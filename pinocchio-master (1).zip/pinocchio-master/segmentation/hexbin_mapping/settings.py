region = {
    'oakland': dict(
        x_min=-13638544.3014,
        x_max=-13596542.1543,
        y_min=4534894.2326,
        y_max=4565010.4218,
        timezone='America/Los_Angeles'),
    'madrid': dict(
        x_min=-416448.0394,
        x_max=-406912.5201,
        y_min=4921025.4356,
        y_max=4931545.0816,
        timezone='Europe/Madrid')
}
